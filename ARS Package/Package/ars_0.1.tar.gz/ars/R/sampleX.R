source("./R/integration.R")

sampleX <- function(m,b,z) {
  #Calculates a potential sample value x

  #Integrates over each of the segment sections
  s <- unlist(sapply(1:(length(z)-1),FUN=function(i) expInteg(m[i],b[i],z[i],z[i+1])))
  #Sums each area; divides each segment area by total to normalize
  total <- sum(s)
  s <- s/total
  #Random sample from a uniform[0,1]
  U <- runif(1)
  #Calculates the cdf using cumsum function
  cdf <- cumsum(s)
  #Selects segment to sample from by determining where U would fall
  for(i in 1:length(s)) {
    if(U < cdf[i]) {break}
  }
  #Solves for x using inverse cdf method
  if(i==1) cdf <- 0 else cdf <- cdf[i-1]
  if(m[i]==0){
    x <- (total*(U-cdf)/exp(b[i]))+z[i]
  }
  else{
    x <- log((m[i]*total*(U-cdf)/exp(b[i]))+exp(m[i]*z[i]))/m[i]
  }
  return(x)
}
