intersection <- function(x0, x1, hx0, hx1, hpx0, hpx1){
  #Calculates the intersection point between two line segments 
  #hx0 is the log f value of current x; hx1 is that of next x
  #hpx0 is the dlog f value of current x; hpx1 is that of next x
  if (hpx0 == hpx1) {
    return((x0 + x1)/2)
  } else {
    return((hx1 - hx0 - x1*hpx1 + x0*hpx0) / (hpx0 - hpx1))
  }
}