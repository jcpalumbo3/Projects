nDeriv <- function(f,x,e = .Machine$double.eps,...) {
  #Calculates the first numerical derivative 
  x <- as.numeric(x)
  tolerance <- 5e-6
  fp <- (log(f(x+tolerance,...)) - log(f(x-tolerance,...)))/(2*tolerance) # central difference
  return (fp)	
}

nDDeriv2 <- function(f,x,...){
  #Calculates the second numerical derivative 
  x<-as.numeric(x)
  tolerance <- 5e-6
  if (abs(tolerance/x) > 1e-8){
    fpp <- (log(f(x+tolerance,...))-2*log(f(x,...))+log(f(x-tolerance,...)))/(tolerance^2)
    return (fpp)}
  else{
    return (NaN)
  }
}