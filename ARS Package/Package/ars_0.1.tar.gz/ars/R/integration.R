expInteg <- function(m, b, z0, z1) {
  #Calculates integral of an exponential of a line segment 
  if (abs(m) < 1e-10) {
    return(exp(b)*(z1-z0))
  } else if ((exp(b)==Inf | exp(b)==-Inf) & ((exp(m*z1)-exp(m*z0))==0)) {
    return(0)
  } else {
    return(exp(b)/m*(exp(m*z1)-exp(m*z0)))
  }
}