update <- function(index, x_new, hx_new, hpx_new, Tk, hx, hpx, z, upper, lower) {
  #Updates vectors when new sample value is added
  uh <- upperhull(hx_new, hpx_new, x_new)
  last <- length(Tk)
  #Update depends on whether point is added to beginning, middle, or end
  if (index == 1) {
    z1 <- intersection(x_new, Tk[1], hx_new, hx[1], hpx_new, hpx[1])	
    z <- c(z[1], z1, z[2:length(z)])
    lh <- lowerhull(x_new, Tk[1], hx_new, hx[1])
    lower$m <- c(lh$m ,lower$m)
    lower$b <- c(lh$b, lower$b)
    Tk <- c(x_new, Tk)
    upper$m <- c(uh$m, upper$m)
    upper$b <- c(uh$b, upper$b)
    hx <- c(hx_new, hx)
    hpx <- c(hpx_new, hpx)
  } else if (index == last+1) {
    z0 <- intersection(Tk[last], x_new, hx[last], hx_new, hpx[last], hpx_new)	
    z <- c(z[1:length(z)-1],z0,z[length(z)])
    lh <- lowerhull(Tk[last], x_new, hx[last], hx_new)
    lower$m <- c(lower$m, lh$m)
    lower$b <- c(lower$b, lh$b)
    Tk <- c(Tk, x_new)
    upper$m <- c(upper$m, uh$m)
    upper$b <- c(upper$b, uh$b)
    hx <- c(hx, hx_new)
    hpx <- c(hpx, hpx_new)
  } else {
    z0 <- intersection(Tk[index-1], x_new, hx[index-1], hx_new, hpx[index-1], hpx_new)
    z1 <- intersection(x_new, Tk[index], hx_new, hx[index], hpx_new, hpx[index])
    z <- c(z[1:index-1], z0, z1, z[(index+1):length(z)])
    lh0 <- lowerhull(Tk[index-1], x_new, hx[index-1], hx_new)
    lh1 <- lowerhull(x_new, Tk[index], hx_new, hx[index])
    if (index == 2) {
      lower$m <- c(lh0$m, lh1$m, lower$m[index:(last-1)])
      lower$b <- c(lh0$b, lh1$b, lower$b[index:(last-1)])
    } else if (index == last) {
      lower$m <- c(lower$m[1:(index-2)], lh0$m, lh1$m)
      lower$b <- c(lower$b[1:(index-2)], lh0$b, lh1$b)
    } else {
      lower$m <- c(lower$m[1:(index-2)], lh0$m, lh1$m, lower$m[index:(last-1)])
      lower$b <- c(lower$b[1:(index-2)], lh0$b, lh1$b, lower$b[index:(last-1)])
    }
    Tk <- c(Tk[1:index-1], x_new, Tk[index:last])
    upper$m <- c(upper$m[1:index-1], uh$m, upper$m[index:last])
    upper$b <- c(upper$b[1:index-1], uh$b, upper$b[index:last])
    hx <- c(hx[1:index-1], hx_new, hx[index:last])
    hpx <- c(hpx[1:index-1], hpx_new, hpx[index:last])
  }
  return(list("Tk"=Tk, "z"=z, "hx"=hx, "hpx"=hpx, "upper"=upper, "lower"=lower))
}
