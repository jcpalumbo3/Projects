srtest <- function(xs,l,u,f,...){
  #Performs squeeze and rejection test to determine if sample value is accepted
  w <- runif(1)
  stest <- FALSE
  rtest <- FALSE
  #Squeeze test
  st <- exp(l-u)
  if(st >= w){
    #True/False;add new sample point
    return(list("stest"=!stest,"rtest"=rtest)) 
  }
  #Rejection test
  else if(exp(log(f(xs,...))-u) >= w){   
    #False/True; add new sample point/abscissa
    return(list("stest"=stest,"rtest"=!rtest)) 
  } 
  else{
    #False/False; add new abscissa
    return(list("stest"=stest,"rtest"=rtest)) 
  }
  
}