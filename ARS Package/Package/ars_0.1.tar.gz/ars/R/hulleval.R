upperhull <- function(hx0, hpx0, x0){
  #Calculates slope/intercept for upperhull in standard linear equation: y=mx+b
  m <- hpx0
  b <- hx0 - hpx0*x0 
  return(list("m"=m,"b"=b))
}

lowerhull <- function(x0, x1, hx0, hx1) {
  #Calculates slope/intercept for lowerhull in standard linear equation: y=mx+b
  m <- (hx1-hx0) / (x1-x0)
  b <- (hx0*x1 - hx1*x0) / (x1-x0)
  return(list("m"=m, "b"=b))
}