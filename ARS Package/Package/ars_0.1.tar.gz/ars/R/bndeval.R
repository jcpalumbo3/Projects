bndeval <- function(mode, xs, index, m, b, min=-Inf){
  #Evaluates upperhull and lowerhull at sample value x 
  val = m[index-1]*xs+b[index-1] 
  #Sets lower bound to be zero if sample lies outside current samples
  if (mode == "lower" & (index == 1 || index == (length(m)+2) ) ){
    val <- min  
  }
  return(val)
}