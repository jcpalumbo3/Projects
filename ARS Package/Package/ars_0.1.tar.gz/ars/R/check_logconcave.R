check_logconcave <- function(f,x,maximum,lb,ub,tolerance=.Machine$double.eps^0.25,...){
  #Checks to ensure point achieves log concavity
  #If nDeriv returns an NaN value, return TRUE or raise warning indicating we 
  #cannot check log concavity 
  if(x<lb|x>ub){
    warnings("The point you want to check logconcavity is not within the given interval")
  }
  
  if(is.nan(nDeriv(f,x,...))|(is.nan(nDDeriv2(f,x,...)))){
    warning("Not able to check logconcavity at x because f'(x) or f''(x) is not available")
    return (TRUE)
  }
  
  if(abs(x-maximum)<tolerance){
    warning("Not able to check logconcavity at x because x is too close to the maximum of f")
    return (TRUE)
  }
  
  if(abs(x-lb)<tolerance){
    warning("Not able to check logconcavity at x because x is too close to the left boundary")
    return (TRUE)    
  }
  
  if(abs(x-ub)<tolerance){
    warning("Not able to check logconcavity at x because x is too close to the right boundary")
    return (TRUE)    
  }
  
  if(nDDeriv2(f,x,...)<=tolerance*10){
    return (TRUE)
  }
  #  else if(x==maximum){
  #   return (TRUE)
  #}
  else{
    print(x)
    stop("The density function is not log-concave at the point shown above!")
  }
  
}