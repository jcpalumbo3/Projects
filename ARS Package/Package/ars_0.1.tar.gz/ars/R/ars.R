source("./R/choose_init.R")
source("./R/derivative.R")
source("./R/intersection.R")
source("./R/hulleval.R")
source("./R/sampleX.R")
source("./R/bndeval.R")
source("./R/check_logconcave.R")
source("./R/update.R")
source("./R/srtest.R")

ars <- function(f,lb=-Inf,ub=Inf,n,tolerance=.Machine$double.xmax^0.3,...) {
  #Sampling method for log-concave probability density functions

  #Check validity of inputs
  if(!is.numeric(c(lb,ub,n,tolerance,...))) stop("All inputs must be numeric.")
  if(lb>=ub) stop("Lowerbound must be less than upperbound.")
  if(n<=0) stop("Sample size n must be a positive number.")
  if(tolerance<0 || tolerance>.Machine$double.xmax) stop("Tolerance must be
                                            between zero and machine epsilon.")
  if(integrate(f,lb,ub,...)$value==Inf) stop("Function f must have finite integration.")

  #Initialization step: choose starting points; calculate envelope and squeeze
  if(lb < (-tolerance)){
    lb <- -(tolerance^0.25)
  }
  if(ub > (tolerance)){
    ub <- tolerance^0.25
  }
  maximum <- optimize(f,maximum = TRUE,lower=lb,upper=ub, log=TRUE,...)$maximum
  #Checks whether given user interval is within a legitimate domain
  if(maximum > tolerance^0.2){
    stop("not able to compute the mode! Please give the legitimate upper and
         lower boundary for the density")
  }
  Tk <- choose_init(f,lb,ub,maximum,...)
  print("The inital values are:")
  print(Tk)
  #Tk <- c(0.49,0.5,0.51)
  hx <- log(f(Tk,...))
  hpx <- nDeriv(f,Tk,...)
  j=length(Tk)
  z <- c(lb, unlist(sapply(1:(length(Tk)-1),FUN=function(i) intersection(Tk[i],Tk[i+1],hx[i],hx[i+1], hpx[i], hpx[i+1]) )), ub)
 # z <- c(lb, intersection(Tk[1:j-1],Tk[2:j],hx[1:j-1],hx[2:j],hpx[1:j-1],hpx[2:j]), ub)
  upper <- upperhull(hx, hpx, Tk)
  lower <- lowerhull(Tk[1:j-1],Tk[2:j],hx[1:j-1],hx[2:j])

  #Sampling/updating step
  x <- c()
  count=0
  while(count<n){
    #Squeeze and rejection test
    xs <- sampleX(upper$m,upper$b,z)
    if (f(xs,...)!=0) {
       z <- sort(z)
		 lInd <- findInterval(xs,Tk)+1
		 uInd <- findInterval(xs,z)+1
		 min <- log(f(lb,...))
		 u <- bndeval("upper",xs, uInd, upper$m, upper$b)
		 l <- bndeval("lower",xs, lInd, lower$m, lower$b, min)
		 test <- srtest(xs, l, u, f, ...)
		 if(test$stest & check_logconcave(f,xs,maximum,lb,ub,...)){  #xs is accepted; no need to be added to Tk
			count <- count + 1
			x <- c(x, xs)
		 } else {			#Otherwise, added to Tk; run rejection test
			hx_new <- log(f(xs,...))
			hpx_new <- nDeriv(f,xs,...)
			update_list <- update(lInd, xs, hx_new, hpx_new, Tk, hx, hpx, z, upper, lower)
			Tk <- update_list$Tk
			z <- update_list$z
			hx <- update_list$hx
			hpx <- update_list$hpx
			upper <- update_list$upper
			lower <- update_list$lower
      }
      if(test$rtest & check_logconcave(f,xs,maximum,lb,ub,...)) {
        count <- count + 1
        x <- c(x, xs)
      }
    }
  }
  return(x)
}

