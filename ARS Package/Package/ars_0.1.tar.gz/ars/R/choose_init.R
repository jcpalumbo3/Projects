choose_init <- function(f,lb,ub,maximum,tolerance=.Machine$double.eps^0.25,default = 0.1,...){
  #Chooses starting points: mode, one value to left, one value to right 
  #f is density, lb is lower bound, ub is upper bound, default is value used 
  #to choose left and right points
  
  if(maximum>1e10|maximum<(-1e10)){
    stop("The mode for the density within the given interval is not valid!")
  }
  left <- maximum - min(default,maximum-lb)
  right <- maximum + min(default,ub-maximum)
  
  init <- c(left,maximum,right)
  init  <- sort(init)
  init <- unique(init)
  
  if((left==lb)&(right!=ub)){
    left <- left+tolerance  
  }
  
  if((right==ub)&(left!=lb)){
    right <- right-tolerance
  }
  
  if((right==ub)&(left==lb)){
    left <- left+tolerance
    right <- right-tolerance
  }
  
  init <- c(left,maximum,right)
  init  <- sort(init)
  init <- unique(init)
  if ((!check_logconcave(f,left,maximum,lb,ub,...))|(!check_logconcave(f,right,maximum,lb,ub,...))){
    stop("The function is not log-concave!")
  }
  
  return (init)
}